//
//  AboutViewController.h
//  test
//
//  Created by Ya on 11/10/15.
//  Copyright © 2015 Ya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController

@property (nonatomic,weak) IBOutlet UIWebView *webView;

-(IBAction) closePage;

@end
