//
//  AppDelegate.h
//  test
//
//  Created by Ya on 11/9/15.
//  Copyright © 2015 Ya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

